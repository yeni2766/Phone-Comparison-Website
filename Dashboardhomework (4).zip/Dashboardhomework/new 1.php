
//table new deal


		<?php foreach ($row1 as $result1): ?>
<h1 class = 'display-5'>Best Deal<h1>
<table class="table table-dark tabledeal " id = 'table'>
  <thead>
    <tr>

      <th scope="col">Product Name</th>
      <th scope="col">Store</th>
      <th scope="col">Price</th>
	  <th scope="col">Buy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td scope="row"><?=$result['phone_name']?></th> 
     
      <td><button type="button" class="btn btn-primary">OnBuy.com</button> </td>
 <td>1</td>
       <td><button type="button" class="btn btn-primary">Buy Now</button> </td>
    </tr>
    
  </tbody>
</table>
<?php endforeach; ?>	

		<?php foreach ($row1 as $result1): ?>
<table class="table table-dark tabledeal " id = 'table'>
  <thead>
    <tr>

      <th scope="col">Product Name</th>
      <th scope="col">Store</th>
      <th scope="col">Price</th>
	  <th scope="col">Buy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td scope="row"><?=$result['phone_name']?></th>
     
      <td><button type="button" class="btn btn-primary">OnBuy.com</button> </td>
 <td>1</td>
       <td><button type="button" class="btn btn-primary">Buy Now</button> </td>
    </tr>
    
  </tbody>
</table>
<?php endforeach; ?>	



.tabledeal{
	font-size:10px;
	width:100px;
height:10%;
position:relative;
right:15px;
bottom:20px;
}



.tabledeal{
	font-size:0.5rem;
	width:70%;
height:10%;
}










function clickHandler(click){
	const points = myChart.getElementsAtEventForMode(click, 'nearest', {intersect:true}, true)
	
	if (points.length){
		const firstPoint = points[0];
		console.log(firstPoint);
		
	}
		
		
	}

	ctx.onclick = clickHandler;
            }
window.open("index.php?page=individualphone&phone_name=" +labels);

//////////////function graphClickEvent(event, array){
    if(array[0]){
const labels = myChart.data.labels[0];
console.log(labels);
    }
}


#sidebar1 {
height:0px;
width:100%;
position:absolute;
background-color:#DCDCDC;
top:0;
border-right:1px solid #d3d3d3;
box-shadow: 0px 0px 5px 0px rgb(211,211,211);

}
#sidebar1{
transition:height 1s;

}

@media (max-width: 767px) {
	.searchbox #phonedata{
		position:absolute;
		right:10px;
	}	
	
	 input[type=text]{

	width:70%;
	
	
	
}
.container{

}
 #openbutton{

display:none;
}
 
 
  .pp {
    border-bottom: 1px solid black !important;
	position:relative;
	
  }
  
  
#sidebar{
display:none;

}
#dashboardcontent{
margin-left : 0px;

}

#openbutton{

visibility:hidden;
}
#openmobilebutton{

visibility:visible;
}

}

#sidebar .closemenubutton{

	position: absolute;
  top: 0;
  right: 5px;
  font-size: 36px;
  margin-left: 50px;
	text-decoration:none;
	
}
#sidebar1 .closemenubutton{

	position: absolute;
  top: 0;
  right: 5px;
  font-size: 36px;
left:0;
	text-decoration:none;
	padding-left:10px;
	color:black;
	
}
.h4{
	margin-left:45px;
	font-weight:bold;
	margin-top:90px;
	color:purple;
	
	
}
.openmenubutton {
visibility:hidden;
  font-size: 20px;
  cursor: pointer;
background-color:transparent;
  color: black;
  padding: 20px 15px;
  border: none;
}

.openmobilemenubutton {
visibility:hidden;
  font-size: 20px;
  cursor: pointer;
background-color:transparent;
  color: black;
  padding: 20px 15px;
  border: none;
  position:relative;
  bottom:55px;
}

#dashboardcontent {
  transition: margin-left 1s; 
  padding: 20px;
}
  input:focus, textarea:focus, select:focus{
        outline: none;
    }
@media screen and (max-height: 450px) {
  .sidebar {padding-top: 15px;}
  .sidebar a {font-size: 18px;}
}
body{
	
	overflow-x:hidden
}

#phonedata{

	
}
		
	
}
#search{
	border:none;
	width:20%;
		background:transparent;
	border-bottom:1px solid black;
  font-family: quicksand;
  font-size:1rem;

	
	
}

.sidebar a {
  padding: 8px 8px 8px 32px;
  position:relative;
  top:130px;
  text-decoration: none;
  font-size: 20px;
  font-family:quicksand;
  font-weight:bold;
  color: black;
  display: block;
  transition: 0.4s;
}

.h5{
	position:relative;
right:15px;
	font-family:quicksand;
	font-weight:bold;
	font-size:25px;
	
	color:#080808;
	
	
}

 input[type=text]{
	border:none;
	transition:all 1s ease;
	width:50%;
		background:transparent;
	border-bottom:1px solid black;
  font-family: quicksand;
  font-size:1rem;

	
	
}
.brand a{
	text-decoration:none;
	color:black;
	cursor:black;
}
input:focus{
	width:100%;
	
	
}
html,body
{
background-color:#F4F0F0;
font-family:quicksand;
}
a{
	
	text-decoration:none;
}


.brandfinder{
	
background-color:	purple;
	
}

.phonename{
	
	margin-left:20px;
}

#sidebar1 {
height:0px;
width:100%;
position:relative;
background-color:#DCDCDC;
top:0;
border-right:1px solid #d3d3d3;
box-shadow: 0px 0px 5px 0px rgb(211,211,211);

}
































.buy{
	position:relative;
	left:50px;
	bottom:230px;
	height:250px;
	
	
}













.name{
	position:relative;
	right:50px;
	
	
}

.button-74 {
  background-color: #fbeee0;
  border: 2px solid white;
  border-radius: 30px;
  box-shadow: purple 4px 4px 0 0;
  color: black;
  cursor: pointer;
  display: inline-block;
  font-weight: 600;
  font-size: 18px;
  padding: 0 18px;
  line-height: 50px;
  text-align: center;
  text-decoration: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

.button-74:hover {
  background-color: #fff;
}

.button-74:active {
  box-shadow: #422800 2px 2px 0 0;
  transform: translate(2px, 2px);
}

@media (min-width: 768px) {
  .button-74 {
    min-width: 120px;
    padding: 0 25px;
  }
}





















	

.phonedetails{
	
	position:relative;
	top:50px;
left:50px;
}
 .chart{
	display:inline;
	
	
	
}

.table{
	border: 1px solid black;
	width:50%;
	color:black;
}
table, th, td {
border: 1px solid black;
border-collapse: collapse;
}

 td {
padding: 5px;
text-align: left;
background-color:white;
color:black;
border: 1px solid black;
}
th{
	background-color:purple;
	width:20%;
	color:white;
	border: 1px solid white;
}

.chart{
position:relative;
left:550px;
bottom:380px;	
	box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
}











.batterynumber{
	font-size:50px;
	color:#010d01;
	font-weight:bold;
	position:relative;
top:120px;
}
.screensize{
	font-size:60px;
	color:#010d01;
	font-weight:bold;
	position:relative;
top:80px;
}




.megapixel{
	
font-size:80px;
position:relative;
left:100px;
top:130px;
color:#010d01;
font-family:quicksand;
		font-weight:bold;
}
.megapixelnumber{
	
font-size:130px;
position:absolute;
color:#010d01;
top:30px;
	
		font-weight:bold;
}


small{
	position:relative;
	top:100px;
	right:78px;
	color:#010d01;
	
}



.date{
	position:relative;
	top:70px;
right:5px;
	
	
}
.price{
	position:relative;
	top:80px;
left:5px;
	
	
}

.img{
	position:relative;
	left:70px;
	
	
}


.cc{
	    background-color: white;
font-family:quicksand;
font-weight:bold;

   right: 220px;
    list-style-type: none;
    margin: 0;
    min-width: 250px;
    position: absolute;
    top: 55px;
    z-index: 100;
    padding-left: 0
	transition:all 1s ease;
padding-left:10px;
}
#pic{
	vertical-align:middle;
	
	
}
 #user {
	 margin:3px;
	 
 }
	
	

@media only screen and (max-width:400px){
	
	.chartbox{
		width:250px;
		height:25%;
		
		
	}
	
	
}




.brand{
position:relative;
top:10px;
height:50px;
font-family:quicksand;
padding-bottom:30px;
font-weight:bold;
}

#sidebar{
transition:width 1s;

}
.row {

	padding:50px 0px 0px 50px;
	
}
.chart-container{
	position:relative;
	left:50px;
	
	
}
.aa{
position:relative;

box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

	display:inline;
}
#phonedata {

margin-left:400px;

}



.openmenubutton {
visibility:hidden;
  font-size: 20px;
  cursor: pointer;
background-color:transparent;
  color: black;
  padding: 20px 15px;
  border: none;
}
#dashboardcontent {
  transition: margin-left 1s; 
  padding: 20px;
}
  input:focus, textarea:focus, select:focus{
        outline: none;
    }
@media screen and (max-height: 450px) {
  .sidebar {padding-top: 15px;}
  .sidebar a {font-size: 18px;}
}
body{
	
	overflow-x:hidden;
}

#phonedata{

	
}
		
	
}
#search{
	border:none;
	width:20%;
		background:transparent;
	border-bottom:1px solid black;
  font-family: quicksand;
  font-size:1rem;

	
	
}

.sidebar a {
  padding: 8px 8px 8px 32px;
  position:relative;
  top:130px;
  text-decoration: none;
  font-size: 20px;
  font-family:quicksand;
  font-weight:bold;
  color: black;
  display: block;
  transition: 0.4s;
}

.h5{
	position:relative;
left:5px;

	font-family:quicksand;
	font-weight:bold;
	font-size:25px;
	bottom:90px;
	color:#080808;
	
	
}

 input[type=text]{
	border:none;
	transition:all 1s ease;
	width:30%;
		background:transparent;
	border-bottom:1px solid black;
  font-family: quicksand;
  font-size:1rem;

	
	
}

input:focus{
	width:100%;
	
	
}
html,body
{
background-color:#F4F0F0;
font-family:quicksand;
}



.brandfinder{
	
background-color:	purple;
	
}

.phonename{
	
	margin-left:20px;
}

#sidebar{
	
	
 box-shadow: 5px 0 5px -5px #333;
}

a{
	
	text-decoration:none;
}
.aaa{
	
	color:white;
	
}


.tabledeal{
	font-size:20px;
	width:70%;
height:10%;
}


#PhoneChart{
	position:relative;
	right:25px;
	bottom:20px;
	
}